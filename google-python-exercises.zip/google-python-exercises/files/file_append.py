f=open("string.txt","a")
f.write("\n 989")
f.close()

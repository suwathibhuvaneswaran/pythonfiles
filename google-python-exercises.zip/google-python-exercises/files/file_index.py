f=open("string.txt","r")
print(f.read(20))

f=open("sample1.txt","r+")
print(f.mode)
print(f.closed)
print(f.name)

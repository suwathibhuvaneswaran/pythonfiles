try:
   f = open("test.txt","r")   
finally:
   f.close()
